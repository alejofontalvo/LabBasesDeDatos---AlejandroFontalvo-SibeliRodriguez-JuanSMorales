import pyodbc

# Datos de conexión
server = "DESKTOP-F80T3P0\\SQLEXPRESS"  # Asegúrate de escapar la barra invertida
db = "ColombianosExterior_bd"
user = "support"
pws = "sdu2024"

try:
    # Conexión a la base de datos
    conexion = pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "SERVER=" + server + ";"
        "DATABASE=" + db + ";"
        "UID=" + user + ";"
        "PWD=" + pws
    )
    print("Conexión exitosa")
except pyodbc.Error as e:
    print("Error al intentar conectar :",e)

