import pandas as pd
import pyodbc

# Cargar los datos desde el archivo CSV
archivo_csv = "Localización.csv"  # Asegúrate de que este archivo ya contiene la columna de localizaciónloc
df = pd.read_csv(archivo_csv)

# Supongamos que la columna de localización se llama "localizacion"
# Ejemplo de datos en la columna: "(41.153332, 20.168331)"
# Limpiar los datos y separar en dos nuevas columnas
df[['latitud', 'longitud']] = df['Localización'].str.extract(r'\(([^,]+), ([^,]+)\)')

# Convertir las nuevas columnas a tipo numérico
df['latitud'] = pd.to_numeric(df['latitud'], errors='coerce')
df['longitud'] = pd.to_numeric(df['longitud'], errors='coerce')

# Guardar el DataFrame actualizado en un nuevo archivo CSV
nuevo_archivo_csv = "datos_actualizados.csv"
df.to_csv(nuevo_archivo_csv, index=False)

# Si deseas guardar los cambios en la base de datos, puedes hacer lo siguiente
# Datos de conexión a la base de datos
server = "DESKTOP-F80T3P0\\SQLEXPRESS"
db = "ColombianosExterior_bd"
user = "support"
pws = "sdu2024"

try:
    # Conexión a la base de datos
    conexion = pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "SERVER=" + server + ";"
        "DATABASE=" + db + ";"
        "UID=" + user + ";"
        "PWD=" + pws
    )
    print("Conexión exitosa")

    # Guarda los datos actualizados en la base de datos
    for index, row in df.iterrows():
        # Asegúrate de que la tabla y las columnas existen
        cursor = conexion.cursor()
        cursor.execute("""
            UPDATE dbo.ColombianosExt
            SET latitud = ?, longitud = ?
            WHERE Localización = ?
        """, (row['latitud'], row['longitud'], row['Localización']))
    
    conexion.commit()
    cursor.close()

except pyodbc.Error as e:
    print("Error al intentar conectar:", e)

print(f"Nuevas columnas 'latitud' y 'longitud' añadidas y datos guardados en {nuevo_archivo_csv}")
