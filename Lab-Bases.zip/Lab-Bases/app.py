import streamlit as st
import pandas as pd
import pyodbc
import time
import altair as alt
import pydeck as pdk
import folium
import plotly.express as px
from streamlit_folium import st_folium
import matplotlib.pyplot as plt
from streamlit_lottie import st_lottie
import requests
from streamlit_globe import streamlit_globe
import numpy as np

# Función para conectar a la base de datos y obtener un DataFrame
def obtener_datos():
    server = "DESKTOP-F80T3P0\\SQLEXPRESS"
    db = "ColombianosExterior_bd"
    user = "support"
    pws = "sdu2024"

    try:
        conexion = pyodbc.connect(
            "DRIVER={ODBC Driver 17 for SQL Server};"
            "SERVER=" + server + ";"
            "DATABASE=" + db + ";"
            "UID=" + user + ";"
            "PWD=" + pws
        )
        st.success("Conexión exitosa a la base de datos")

        consulta = "SELECT TOP 250000 * FROM dbo.ColombianosExt"
        df = pd.read_sql(consulta, conexion)

        # Mostrar los nombres de las columnas para verificar errores tipográficos
        st.write("Columnas disponibles en el DataFrame:", df.columns.tolist())

        return df, conexion  # Devuelve también la conexión

    except pyodbc.Error as e:
        st.error(f"Error al intentar conectar: {e}")
        return pd.DataFrame(), None  # Devuelve un DataFrame vacío y None si hay error

# Función para cargar Lottie desde una URL
def load_lottie_url(url):
    r = requests.get(url)
    if r.status_code != 200:
        return None
    return r.json()

# URL del archivo Lottie
lottie_url = "https://lottie.host/6211f5c7-ec82-4553-a024-05951f53254a/aiEqZMAgs5.json"
lottie_animation = load_lottie_url(lottie_url)

st.markdown("<h1 style='text-align: center; color: #fe0489;'>Colombianos SIN FRONTERAS</h1>", unsafe_allow_html=True)
st.markdown("<h4 style='text-align: center; color: black;'>Mapeando la diáspora colombiana para entender su impacto global.</h4>", unsafe_allow_html=True)

# CSS para personalizar el fondo y el estilo
def agregar_css_fondo_bienvenida():
    st.markdown("""
    <style>
    @import url("https://fonts.googleapis.com/css2?family=Londrina+Sketch&display=swap");
    body {
        background-color: #ffffff;
    }
    .stApp {
       background-image: url("https://www.dropbox.com/scl/fi/lght0ds6itkbz2omvv3c6/FondoCirculitos.png?rlkey=v8pl083tyfxhhl49w8lcy554q&raw=1");
       background-size: cover; 
       background-position: right; 
       background-repeat: no-repeat;
       width: 100vw; 
       padding: 0px; 
       margin: 0px; 
    }
    h1 {
        font-family: 'Londrina Sketch', cursive;
        font-size: 5em; 
        width: 100%; 
        text-align: center; 
        margin: 20; 
    }
    .boton-personalizado {
        background-color: #fe0489;
        color: #fe0489;
        padding: 20px 30px;
        font-size: 1.2em;
        border: none;
        border-radius: 8px;
        transition: background-color 0.3s ease;
        display: block;
        margin: 20px auto;
        width: 250px;
        text-align: center;
    }
    .boton-personalizado:hover {
        background-color: #000cff;
        cursor: pointer;
    }
    </style>
    """, unsafe_allow_html=True)

# Mostrar la animación Lottie
if lottie_animation:
    st_lottie(lottie_animation, height=300)
else:
    st.error("No se pudo cargar la animación Lottie")

# Página de bienvenida
def pagina_bienvenida():
    agregar_css_fondo_bienvenida()
    
    if 'start_time' not in st.session_state:
        st.session_state['start_time'] = time.time()

    elapsed_time = int(time.time() - st.session_state['start_time'])
    st.write(f"Tiempo en la aplicación: {elapsed_time} segundos")

    if st.button("Ir a la siguiente página", key="boton"):
        with st.spinner("Cargando..."):
            time.sleep(1)
            st.session_state['pagina'] = 'pagina_hola'

# Página "Hola"
def pagina_hola():
    st.title("Datos de la Base de Datos")
    df, conexion = obtener_datos()  # Llama a obtener_datos para recibir la conexión

    if not df.empty and conexion:
        st.write("Aquí están los datos obtenidos:")

        # Convertir la columna 'Edad (años)' a numérica (si es necesario)
        if "Edad (años)" in df.columns:
            df["Edad (años)"] = pd.to_numeric(df["Edad (años)"], errors='coerce')  

        # Filtros dinámicos
        pais = st.multiselect("Selecciona País(es)", options=df["País"].unique(), default=df["País"].unique())
        genero = st.multiselect("Selecciona Género(s)", options=df["Género"].unique(), default=df["Género"].unique())
        grupo_edad = st.multiselect("Selecciona Grupo de Edad", options=df["Grupo_edad"].unique(), default=df["Grupo_edad"].unique())

        df_filtrado = df[(df["País"].isin(pais)) & (df["Género"].isin(genero)) & (df["Grupo_edad"].isin(grupo_edad))]
        st.write(f"Mostrando {len(df_filtrado)} registros después de aplicar los filtros")
        st.dataframe(df_filtrado)

        # Gráfico de barras
        st.title("Gráficos de Distribución por País y Género")
        grafico_barras = alt.Chart(df_filtrado).mark_bar().encode(
            x=alt.X('País:N', sort='-y', title="País"),
            y=alt.Y('count()', title='Cantidad de Personas Registradas'),
            color='Género:N',
            tooltip=['País', 'Género', 'count()']
        ).interactive()
        st.altair_chart(grafico_barras, use_container_width=True)

        # Gráfico de dispersión entre Edad y Estatura
        st.title("Gráfico de Dispersión: Edad vs. Estatura")
        grafico_dispersion = alt.Chart(df_filtrado).mark_circle(size=60).encode(
            x=alt.X('Edad_años:Q', title='Edad'),
            y=alt.Y('Estatura_CM:Q', title='Estatura'),
            color='Género:N',
            tooltip=['Edad_años', 'Estatura_CM', 'Género']
        ).interactive()
        st.altair_chart(grafico_dispersion, use_container_width=True)

        st.sidebar.header('Opciones de Visualización')

        # Selección de la columna para análisis
        column = st.sidebar.selectbox('Selecciona una columna para visualizar', df.columns)

        # Tipo de gráfico
        chart_type = st.sidebar.selectbox(
            'Selecciona el tipo de gráfico',
            ['Histograma', 'Gráfico de Barras', 'Gráfico de Dispersión']
        )

        # Histograma con Plotly
        if chart_type == 'Histograma':
            st.header(f'Histograma de {column}')
            fig = px.histogram(df, x=column, nbins=30, title=f'Histograma de {column}')
            st.plotly_chart(fig, use_container_width=True)

        # Gráfico de barras con Plotly
        elif chart_type == 'Gráfico de Barras':
            st.header(f'Gráfico de Barras de {column}')
            df_counts = df[column].value_counts().reset_index()
            df_counts.columns = [column, 'count']  
            fig = px.bar(df_counts, x=column, y='count', title=f'Gráfico de Barras Interactivo de {column}')
            fig.update_traces(marker=dict(line=dict(color='rgb(8,48,107)', width=1.5)))
            st.plotly_chart(fig, use_container_width=True)

        # Gráfico de dispersión con Plotly
        elif chart_type == 'Gráfico de Dispersión':
            st.header(f'Gráfico de Dispersión entre {column} y otra variable')
            other_column = st.sidebar.selectbox('Selecciona otra columna para el eje Y', df.columns)
            fig = px.scatter(df, x=column, y=other_column, title=f'Dispersión entre {column} y {other_column}')
            st.plotly_chart(fig, use_container_width=True)

        # Resumen estadístico
        if st.sidebar.checkbox('Mostrar resumen estadístico'):
            st.header('Resumen Estadístico')
            st.write(df.describe())


        query_ColExt = """
        SELECT Latitud AS latitude, Longitud AS longitude
        FROM dbo.ColombianosExt
        """
        df_ColExt = pd.read_sql(query_ColExt, conexion)

        # Mostrar el mapa con las ubicaciones
        st.title("Mapa de todas las ubicaciones")
        st.map(df_ColExt[['latitude', 'longitude']])
        


        # Cerrar conexión
        conexion.close()

# Navegación entre páginas
if 'pagina' not in st.session_state:
    st.session_state['pagina'] = 'bienvenida'

if st.session_state['pagina'] == 'bienvenida':
    pagina_bienvenida()
elif st.session_state['pagina'] == 'pagina_hola':
    pagina_hola()


