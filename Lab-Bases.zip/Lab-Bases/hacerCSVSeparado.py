import pandas as pd

# Ruta del archivo CSV original
archivo_csv = "Localización.csv"  # Asegúrate de que este archivo existe

# Cargar los datos desde el archivo CSV
df = pd.read_csv(archivo_csv)

# Imprimir las columnas para verificar su nombre
print("Columnas en el DataFrame:", df.columns.tolist())

# Limpiar espacios en los nombres de las columnas
df.columns = df.columns.str.strip()

# Asegúrate de que la columna de localización se llama "localizacion"
# Ajusta el nombre si es necesario
if 'Localización' in df.columns:
    # Separar latitud y longitud
    df[['latitud', 'longitud']] = df['Localización'].str.extract(r'\(([^,]+), ([^,]+)\)')

    # Convertir las nuevas columnas a tipo numérico
    df['latitud'] = pd.to_numeric(df['latitud'], errors='coerce')
    df['longitud'] = pd.to_numeric(df['longitud'], errors='coerce')

    # Guardar el DataFrame actualizado en un nuevo archivo CSV
    nuevo_archivo_csv = "Localización_actualizados.csv"
    df.to_csv(nuevo_archivo_csv, index=False)
    
    print(f"Nuevas columnas 'latitud' y 'longitud' añadidas y datos guardados en {nuevo_archivo_csv}")
else:
    print("La columna 'localizacion' no se encontró en el DataFrame.")
